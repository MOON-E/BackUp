---
layout: default
title: Data Structures and Object Oriented Design
nav: index
---

## Welcome to CSCI 104

Welcome to CSCI 104 - Data Structures and Object-Oriented Design.  This website will serve as the main portal to all the information and other sites related to this course. 