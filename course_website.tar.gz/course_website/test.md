---
layout: default
title: Initial Meeting Schedule
nav: meetings
---

### Testing MathJax

$$ sin(x^2) $$

Inline equation blah blah. \\( sin(x^2) \\). 

