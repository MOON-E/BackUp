Lab 2
==========

lab 2 practice code. Visit the [lab](http://bits.usc.edu/cs104/labs/lab2/) page for instruction.
