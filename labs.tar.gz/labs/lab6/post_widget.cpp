#include <QString>
#include <QFont>
#include "post_widget.h"

PostWidget::PostWidget(Post* p) {
	post = p;
	layout = new QGridLayout();

	titleLabel = new QLabel(QString::fromStdString(p->title));
	usernameLabel = new QLabel(QString::fromStdString(p->username));
	subredditLabel = new QLabel(QString::fromStdString(p->subreddit));
    karmaLabel = new QLabel(QString::number(p->karma));

	QFont titleFont;
    titleFont.setBold(true);
    titleFont.setPointSize(14);
    titleLabel->setFont(titleFont);

    QFont karmaFont;
    karmaFont.setBold(true);
    karmaFont.setPointSize(30);
    karmaLabel->setFont(karmaFont);

    urlLabel = new QLabel(QString::fromStdString("<a href=\"" + p->url + "\">" + p->url + "</a>"));
    urlLabel->setOpenExternalLinks(true);

	layout->addWidget(karmaLabel, 0, 0, 1, 3);
	layout->addWidget(titleLabel, 0, 3, 1, 2);
	layout->addWidget(subredditLabel, 1, 3, 1, 1);
	layout->addWidget(usernameLabel, 1, 4, 1, 1);
	layout->addWidget(urlLabel, 2, 3, 1, 1);

	setLayout(layout);
	// ADD YOUR CODE HERE.
	// Create the suitable labels and add them to GridLayout properly.
}

PostWidget::~PostWidget() {
	delete titleLabel;
	delete usernameLabel;
	delete subredditLabel;
	delete urlLabel;
	delete karmaLabel;
	delete layout;
}
