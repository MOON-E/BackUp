#include "arraylist.h"
#include "gtest/gtest.h"

class ArrayListTest : public testing::Test {
protected:
	// You can remove any or all of the following functions if its body is empty.

	ArrayListTest() {
		// You can do set-up work for each test here.
	}

	virtual ~ArrayListTest() {
		// You can do clean-up work that doesn't throw exceptions here.		
	}

	// If the constructor and destructor are not enough for setting up
	// and cleaning up each test, you can define the following methods:
	virtual void SetUp() {
		// Code here will be called immediately after the constructor (right
		// before each test).
		list.add(1);
		list.add(2);
		list.add(3);
	}

	virtual void TearDown() {
		// Code here will be called immediately after each test (right
		// before the destructor).
	}

	// Objects declared here can be used by all tests in the test case.
	ArrayList list;
};

TEST_F(ArrayListTest, GetNominal) {
	// Exepct 0th element to be 1, 1st elemnt to be 2, etc.
	for (int i = 0 ; i < 3; i++) {
		EXPECT_EQ(list.get(i), i + 1);
	}
}

TEST_F(ArrayListTest, AddFour) {
	list.add(4);
	EXPECT_EQ(list.size(), 4);
	for (int i = 0 ; i < 4; i++) {
		EXPECT_EQ(list.get(i), i + 1);
	}
}

TEST_F(ArrayListTest, AddFive) {
	list.add(4);
	list.add(5);
	EXPECT_EQ(list.size(), 5);
	for (int i = 0 ; i < 5; i++) {
		EXPECT_EQ(list.get(i), i + 1);
	}
}

TEST_F(ArrayListTest, AddSix) {
	list.add(4);
	list.add(5);
	list.add(6);
	EXPECT_EQ(list.size(), 6);
	for (int i = 0 ; i < 6; i++) {
		EXPECT_EQ(list.get(i), i + 1);
	}
}

TEST_F(ArrayListTest, RemoveBack) {
	list.remove(2);
	EXPECT_EQ(list.size(), 2);
	for (int i = 0 ; i < 2; i++) {
		EXPECT_EQ(list.get(i), i + 1);
	}
}

TEST_F(ArrayListTest, RemoveFront) {
	list.remove(0);
	EXPECT_EQ(list.size(), 2);
	for (int i = 0 ; i < 2; i++) {
		EXPECT_EQ(list.get(i), i + 2);
	}
}

TEST_F(ArrayListTest, SetOffNominal) {
	list.set(1, 7);
	EXPECT_EQ(list.size(), 3);
	EXPECT_EQ(list.get(0), 1);
	EXPECT_EQ(list.get(1), 7);
	EXPECT_EQ(list.get(2), 3);
}
