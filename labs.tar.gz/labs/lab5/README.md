Lab 5
==========

lab 5 practice code. Visit the [lab](http://bits.usc.edu/cs104_su15/labs/lab05.html) page for instruction.
