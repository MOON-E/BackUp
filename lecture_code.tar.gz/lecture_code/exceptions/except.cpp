#include <iostream>
#include <stdexcept>
#include <string>
using namespace std;
int divide(int num, int denom)
{ 
  if(denom == 0)
    throw -1; //invalid_argument("Div by 0");
	if(num == 3) {
		throw string("hi");
	}
  return(num/denom);
}
int f1(int x)
{
	int temp;
	try {
		temp = divide(x, x-2);
	}
	catch(int x) {
		cout << "Caught the error!" << endl;
		return 1;
	}
	catch(string x){
		cout << "Caught the string" << endl;
	}
  return divide(x, x-2);
  return temp;
}

int main()
{
  int res, a;
  cout << "Enter: " << endl;
  cin >> a;
  res = f1(a);
  cout << res << endl;
  return 0;
}
