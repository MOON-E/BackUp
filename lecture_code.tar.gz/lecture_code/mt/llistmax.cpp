#include <iostream>

using namespace std;

struct Item{
  int val;
  Item* next;
};

int findMax(Item* head){
	if(head->next == NULL) return head->val;
	int next_max = findMax(head->next);
	if(head.val >= next_max) return head->val;
	else return next_max;
}

Item* compareTwo(Item* first, Item* second){

}

int main()
{
  Item* head;
  int max = findMax(head);
  cout << max << endl;
  return 0;
}
