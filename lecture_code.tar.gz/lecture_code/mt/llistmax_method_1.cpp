#include <iostream>

using namespace std;

struct Item{
  int val;
  Item* next;
};

int fMHelper(Item* head, int currMax)
{
	if(head == NULL){
		return currMax;
	}
	else {
		if(currMax > head->val){
			fMHelper(head->net, currMax);
		}
		else {
			fMHelper(head->next, head->val);
		}
	}
}

int findMax(Item* head)
{
	return fMHelper(head, 0);
}

Item* compareTwo(Item* first, Item* second){

}

int main()
{
  Item* head;
  int max = findMax(head);
  cout << max << endl;
  return 0;
}
