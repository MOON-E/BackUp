#include <iostream>
#include <sstream>
#include <string>

#include "twiteng.h"

using namespace std;

void displayTweets(vector<Tweet*>& hits);

int main(int argc, char* argv[])
{
  if(argc < 2){
    cerr << "Please provide the twitter data file" << endl;
    return 1;
  }
  TwitEng twit;

  if ( twit.parse(argv[1]) ){
    cerr << "Unable to parse " << argv[1] << endl;
    return 1;
  }



  cout << "=====================================" << endl;
  cout << "Menu: " << endl;
  cout << "  AND term term ...                  " << endl;
  cout << "  OR term term ...                   " << endl;
  cout << "  TWEET username tweet_text" << endl;
  cout << "  QUIT (and write feed files)        " << endl;
  cout << "=====================================" << endl;

while (true) {
      string input, command;
      getline(cin, input);
      stringstream ss(input);

      ss >> command;

      if((command == "AND") || (command == "OR")) {
        vector<string> term_vector;
        string term_string;

        while(ss >> term_string){
        //Caps
            for(unsigned int i=0; i<term_string.size(); i++){
                term_string[i] = toupper(term_string[i]);
            }
          term_vector.push_back(term_string);
        }

        vector<Tweet*> print_out;

        if(command == "AND") print_out = twit.search(term_vector, 0);
        if(command == "OR") print_out = twit.search(term_vector, 1);

        if(print_out.empty()) cout << "No matches." << endl << endl;

        else {
          cout << print_out.size() << " matches:" << endl;

          for(vector<Tweet*>::iterator it = print_out.begin();
                it != print_out.end();
                ++it)
          {
            cout << **it << endl;
          }

          cout << endl;
        }
      }

      if(command == "TWEET"){
        string user_string, text_string;
        stringstream text_ss;
        DateTime dnt;

        ss >> user_string;

        while (ss >> text_string){
            text_ss << text_string << " ";
        }

        text_string = text_ss.str();

        twit.addTweet(user_string, dnt, text_string);

        cout << endl;
      }

      // if(command == "HT") {
      //   twit.check();
      // }

      if(command == "QUIT") {
        twit.dumpFeeds();
        return 0;
      }
    }
}
