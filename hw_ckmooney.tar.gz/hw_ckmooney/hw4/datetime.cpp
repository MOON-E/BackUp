#include "datetime.h"

#include <ctime>
#include <string>
#include <cstdlib>
#include <algorithm>
#include <sstream>
#include <iomanip>

using namespace std;

DateTime::DateTime()
{
    time_t t = time(0);
    struct tm * now = localtime(&t);

    hour = now->tm_hour;
    min = now->tm_min;
    sec = now->tm_sec;
    year = (now->tm_year)+1900;
    month = (now->tm_mon)+1;
    day = now->tm_mday;
}

DateTime::DateTime(int hh, int mm, int ss, int year_, int month_, int day_)
{
    hour = hh;
    min = mm;
    sec = ss;
    year = year_;
    month = month_;
    day = day_;
}

bool DateTime::operator<(const DateTime& other) const
{
    if(year != other.year) return (year-other.year<0);
    else if(month != other.month) return (month-other.month<0);
    else if(day != other.day) return (day-other.day<0);
    else if(hour != other.hour) return (hour-other.hour<0);
    else if(min != other.min) return (min-other.min<0);
    else if(sec != other.sec) return (sec-other.sec<0);
    else return false;
}

ostream& operator<<(ostream& os, const DateTime& other)
{
    os << other.year << "-"
    << setfill('0') << setw(2) << other.month << "-"
    << setfill('0') << setw(2) << other.day << " "
    << setfill('0') << setw(2) << other.hour << ":" 
    << setfill('0') << setw(2) << other.min << ":"
    << setfill('0') << setw(2) << other.sec;
    return os;
}

istream& operator>>(istream& is, DateTime& dt)
{
    string d, t;

    is >> d >> t;

    replace(d.begin(), d.end(), '-', ' ');
    replace(t.begin(), t.end(), ':', ' ');

    stringstream ss;

    ss << d << " " << t;

    if(ss >> dt.year >> dt.month >> dt.day >> dt.hour >> dt.min >> dt.sec){
        return is;
    }
    else DateTime();
    return is;
}