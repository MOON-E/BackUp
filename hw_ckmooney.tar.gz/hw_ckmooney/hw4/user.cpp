#include "user.h"

#include <algorithm>
#include <iterator>

using namespace std;

User::User(string n)
{
	name_ = n;
}

User::~User()
{
	clear();
}

void User::clear()
{
	followers_.clear();
	leaders_.clear();
	tweets_.clear();
}

string User::name() const
{
	return name_;
}

set<User*> User::followers() const
{
	return followers_;
}

set<User*> User::following() const
{
	return leaders_;
}

list<Tweet*> User::tweets() const
{
	return tweets_;
}

void User::addFollower(User* u)
{
	followers_.insert(u);
}

void User::addFollowing(User* u)
{
	leaders_.insert(u);
}

void User::addTweet(Tweet* t)
{
	tweets_.push_back(t);
}

vector<Tweet*> User::getFeed()
{
	vector<Tweet*> myfeedvec;

	for(list<Tweet*>::iterator it = tweets_.begin();
		it != tweets_.end();
		++it)
	{
		myfeedvec.push_back(*it);
	}

	for(set<User*>::iterator it = leaders_.begin();
		it != leaders_.end();
		++it)
	{
		User* hold_user = *it;
		list<Tweet*> holder = hold_user->tweets();

		for(list<Tweet*>::iterator jt = holder.begin();
			jt != holder.end();
			++jt)
		{
			myfeedvec.push_back(*jt);
		}
	}

// //Debug
// 	cout << name() << endl;

// 	for(vector<Tweet*>::iterator it = myfeedvec.begin();
// 		it != myfeedvec.end();
// 		++it)
// 	{
// 		Tweet* hold_tweet = *it;
// 		cout << hold_tweet->time() << hold_tweet->text() << endl;
// 	}

	sort(myfeedvec.begin(), myfeedvec.end(), TweetComp());

// //Debug
// 	cout << "sorted" << endl;

// 	for(vector<Tweet*>::iterator it = myfeedvec.begin();
// 		it != myfeedvec.end();
// 		++it)
// 	{
// 		Tweet* hold_tweet = *it;
// 		cout << hold_tweet->time() << hold_tweet->text() << endl;
// 	}

	return myfeedvec;
}
