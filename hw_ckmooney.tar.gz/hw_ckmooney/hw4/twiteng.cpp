#include "twiteng.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <iterator>
#include <algorithm>

using namespace std;

TwitEng::TwitEng(){

}

TwitEng::~TwitEng()
{
	users_.clear();
	hashtag_map.clear();
}

bool TwitEng::parse(char* filename)
{

//Open file, check it's valid
	ifstream infile(filename);
	if(infile.fail()) return true;

//Get the user count from the first line
	int user_count = 0;
	infile >> user_count;

//Initialize holding strings and iterators
	string holder, user_holder, leader_holder;
	map<string, User*>::iterator it, jt;

//Advance getline
	getline(infile, holder);

//For each user...
	for(int i=0; i<user_count; i++){

	//Get the line, convert to stringstream
		getline(infile, holder);
		stringstream ss(holder);

	//Return if a string is not found
		if(ss >> user_holder) {

		//Find the user
			it = users_.find(user_holder);

		//If new, insert it
			if(it == users_.end()) {
				User* new_user = new User(user_holder);
				users_.insert(pair<string, User*>(user_holder, new_user));
				it = users_.find(user_holder);
			}
		}
		else return true;

	//For each name after the first...
		while(ss >> leader_holder) {

		//Find the user
			jt = users_.find(leader_holder);

		//If new, insert it
			if(jt == users_.end()) {
				User* new_user = new User(leader_holder);
				users_.insert(pair<string, User*>(leader_holder, new_user));
				jt = users_.find(leader_holder);
			}

		//Add users to each other's following/follower set
			it->second->addFollowing(jt->second);
			jt->second->addFollower(it->second);
		}
	}

//For each other line (the tweets)...
	while(getline(infile, holder)){

	//Initialize
		stringstream ss(holder);
		stringstream text_ss;

		string username, text_holder;

		DateTime dnt;

	//Read in data
		ss >> dnt >> username;
		while (ss >> text_holder){
			text_ss << text_holder << " ";
		}

		string text = text_ss.str();

		addTweet(username, dnt, text);
	}

	return false;
}

void TwitEng::addTweet(string& username, DateTime& time_, string& text)
{
	Tweet* new_tweet = new Tweet(users_[username], time_, text);

	vector<string> hash_holder = new_tweet->hashTags();

	for(vector<string>::iterator it = hash_holder.begin();
		it != hash_holder.end();
		++it)
	{
		string hash_string = *it;

		map<string, vector<Tweet*> >::iterator jt = hashtag_map.find(hash_string);

		if(jt==hashtag_map.end()){
			vector<Tweet*>* new_vector = new vector<Tweet*>();
			hashtag_map.insert(pair<string, vector<Tweet*> > (hash_string, *new_vector));
			jt = hashtag_map.find(hash_string);
		}

		jt->second.push_back(new_tweet);

		sort(jt->second.begin(), jt->second.end(), TweetComp());
	}

	users_[username]->addTweet(new_tweet);
}

vector<Tweet*> TwitEng::search(vector<string>& terms, int strategy)
{
	vector<Tweet*> return_v, hold_v;
	vector<string>::iterator it = terms.begin();
	vector<Tweet*>::iterator jt;

	return_v = hashtag_map[*it];

//AND
	if (strategy==0){
		for(vector<string>::iterator it = terms.begin()+1;
		it != terms.end();
		++it)
		{
			jt = return_v.begin();
			hold_v = hashtag_map[*it];

			jt = set_intersection(return_v.begin(), return_v.end(),
				hold_v.begin(), hold_v.end(), return_v.begin(),
				TweetComp());

			return_v.resize(jt-return_v.begin());
		}
	}
//OR
	else if (strategy==1){
		for(vector<string>::iterator it = terms.begin();
		it != terms.end();
		++it)
		{
			hold_v = hashtag_map[*it];
			for(vector<Tweet*>::iterator jt = hold_v.begin();
			jt != hold_v.end();
			++jt)
			{
				return_v.push_back(*jt);
			}
		}

		sort(return_v.begin(), return_v.end(), TweetComp());
		jt = unique(return_v.begin(), return_v.end(), TweetEQ());
		return_v.resize(distance(return_v.begin(), jt));
	}

	return return_v;
}

void TwitEng::dumpFeeds()
{
	for(map<string, User*>::iterator it = users_.begin();
		it != users_.end();
		++it)
	{
		ofstream outfile;
		outfile.open((it->first + ".txt").c_str());

		outfile << it->first << endl;

		vector<Tweet*> feed = it->second->getFeed();

		for(vector<Tweet*>::iterator jt = feed.begin();
		jt != feed.end();
		++jt)
		{
			outfile << **jt << endl;
		}

		outfile.close();
	}
}

// void TwitEng::check()
// {
// 	for(map<string, vector<Tweet*> >::iterator it = hashtag_map.begin();
// 		it != hashtag_map.end();
// 		++it)
// 	{
// 		cout << it->first << " " << it->second.size() << endl;
// 	}
// }