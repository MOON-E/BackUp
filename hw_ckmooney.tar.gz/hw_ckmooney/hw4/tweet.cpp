#include "tweet.h"

#include <cctype>
#include <sstream>

using namespace std;

Tweet::Tweet()
{
    DateTime datetime_(-1, -1, -1, -1, -1, -1);
}

Tweet::Tweet(User* user, DateTime& tyme, string& text)
{
    user_ = user;
    username_ = user->name();
    datetime_ = tyme;
    text_ = text;

    string holder;
    stringstream ss(text);
    while (ss >> holder) {
        if(holder.find("#")!=string::npos) {
            holder.erase(0, 1);

        //Caps
            for(unsigned int i=0; i<holder.size(); i++){
                holder[i] = toupper(holder[i]);
            }

            hashtags_.push_back(holder);
        }
    }

}

DateTime const & Tweet::time() const
{
    return datetime_;
}

string const & Tweet::text() const
{
    return text_;
}

vector<string> Tweet::hashTags() const
{
    return hashtags_;
}

bool Tweet::operator<(const Tweet& other) const
{
    if(datetime_ < other.datetime_) return true;
    else return false;
}

ostream& operator<<(ostream& os, const Tweet& t)
{
    os << t.datetime_ << " " << t.username_ << " " << t.text_;
    return os;
}

User* Tweet::user() const
{
    return user_;
}