struct Item {
  int val;
  Item* next;
};