#include "llistint.h"
#include <cstdlib>
#include <stdexcept>

LListInt::LListInt()
{
  head_ = NULL;
  tail_ = NULL;
  size_ = 0;
}

LListInt::~LListInt()
{
  clear();
}

bool LListInt::empty() const
{
  return size_ == 0;
}

int LListInt::size() const
{
  return size_;
}

/**
 * Complete the following function
 */
void LListInt::insert(int loc, const int& val)
{
	Item *newItem = new Item;
	newItem->val = val;

	if (loc==0) {
		newItem->prev = NULL;
		newItem->next = head_;
		head_ = newItem;
	}

	else if (loc==size_){
		newItem->prev = tail_;
		newItem->next = NULL;
		tail_ = newItem;
	}

	else if (loc<0 || loc>size_){	
		//nothing
	}

	else {
		Item *prevItem = getNodeAt(loc-1);
		Item *nextItem = getNodeAt(loc);

		newItem->next = nextItem;
		newItem->prev = prevItem;

		prevItem->next = newItem;
		nextItem->prev = newItem;
	}

}

/**
 * Complete the following function
 */
void LListInt::remove(int loc)
{

	if (loc==0) {
		Item *newHead = head_->next;

		newHead->prev = NULL;
		delete head_;
		head_ = newHead;
	}

	else if (loc==(size_-1)){
		Item *newTail = tail_->prev;

		newTail->next = NULL;
		delete tail_;
		tail_ = newTail;
	}

	else if (loc<0 || loc>(size_-1)){	
		//nothing
	}

	else {
		Item *removedItem = getNodeAt(loc);
		Item *prevItem = removedItem->prev;
		Item *nextItem = removedItem->next;

		delete removedItem;
		prevItem->next = nextItem;
		nextItem->prev = prevItem;

	}
}

void LListInt::set(int loc, const int& val)
{
  Item *temp = getNodeAt(loc);
  temp->val = val;
}

int& LListInt::get(int loc)
{
  if(loc < 0 || loc >= size_){
    throw std::invalid_argument("bad location");
  }
  Item *temp = getNodeAt(loc);
  return temp->val;
}

int const & LListInt::get(int loc) const
{
  if(loc < 0 || loc >= size_){
    throw std::invalid_argument("bad location");
  }
  Item *temp = getNodeAt(loc);
  return temp->val;
}

void LListInt::clear()
{
  while(head_ != NULL){
    Item *temp = head_->next;
    delete head_;
    head_ = temp;
  }
  tail_ = NULL;
  size_ = 0;
}


LListInt::Item* LListInt::getNodeAt(int loc) const
{
  Item *temp = head_;
  if(loc >= 0 && loc < size_){
    while(temp != NULL && loc > 0){
      temp = temp->next;
      loc--;
    }
    return temp;
  }
  else {
    //throw std::invalid_argument("bad location");
    return NULL;
  }
}