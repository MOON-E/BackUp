Problem 1
  - a) unmodified
  - b) README.md - modified
    - fun_problem.txt - untracked
  - c) both are staged
  - d) both are modified
  - e) README.md - staged
    - fun_problem.txt - untracked
    - the contents are empty; we made a new blank file, committed it, changed it, then stopped tracking it. Since we never committed the file after changing it, all we have left is the original blank file we committed.
  - f) modified
    - we modified the file before committing it, which knocks it out of the staged status


Problem 2
  - a) TAB
  - b) clean and shape1 get called
    - `rm -f ./*.o *~ shape1 shape2 ./*~`
    - `g++ -o $@ $^ -I. -std=c++11 -ggdb -lm`
  - c) to ensure your make file will properly run clean (or whatever the .PHONY is) even if a file of the asme name is present.
  - d) Makefile, makefile

Problem 3
  - 
