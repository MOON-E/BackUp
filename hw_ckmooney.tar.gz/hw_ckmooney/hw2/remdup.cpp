#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
using namespace std;

struct Item {
  int val;
  Item* next;
};

void buildList(Item*& head, int v) {
	Item* newptr = new Item;
	newptr->val = v;
	newptr->next = NULL;

	if (head == NULL) head = newptr;
	else {
		Item* temp = head;
		while(temp->next){
			temp = temp->next;
		}
		temp->next = newptr;
	}
}

void printtest(Item*& head) {
	cout << head->val << " ";
	if (head->next) printtest(head->next);
}

void removeConsecutive(Item* head){
	
}

int main (int argc, char* argv[]) {
	//check
	if (argc != 3) cout << "Invalid" << endl;

	else {
		int value;
		string line_one;
		string line_two;
		Item* head1 = NULL;
		Item* head2 = NULL;

		ifstream in_file(argv[1]);
		ofstream out_file(argv[2]);

		getline(in_file, line_one);
		getline(in_file, line_two);

		stringstream l1ss(line_one);
		stringstream l2ss(line_two);

		while(l1ss >> value) {
			buildList(head1, value);
		}
		while(l2ss >> value) {
			buildList(head2, value);
		}

		printtest(head1);
		printtest(head2);
	}
}