#include "setstr.h"
#include <cstdlib>
#include <stdexcept>
#include <string>

using namespace std;

SetStr::SetStr()
{
  	nextLoc = 0;
}

SetStr::~SetStr()
{
	list_.clear();
}

bool SetStr::empty() const
{
  return list_.empty();
}

int SetStr::size() const
{
  return list_.size();
}

bool SetStr::exists(const std::string& val) const
{
	for(int i=0; i<list_.size(); i++){
		if(list_.get(i)==val) return true;
	}
	return false;
}

void SetStr::insert(const std::string& val)
{
	if(!exists(val)) list_.push_back(val);
}

void SetStr::remove(const std::string& val)
{
	if(exists(val)){
		for(int i=0; i<list_.size(); i++){
			if(list_.get(i)==val) list_.remove(i);
		}
	}
}

std::string const* SetStr::first()
{
	nextLoc = 0;
	return &list_.get(0);
}

std::string const* SetStr::next()
{
	nextLoc++;
	return &list_.get(nextLoc);
}

SetStr SetStr::setUnion(const SetStr &other) const
{
	SetStr unionSet(*this);

	for(int i=0; i<other.size(); i++){
		unionSet.insert(other.list_.get(i));
	}

	return unionSet;
}

SetStr SetStr::setIntersection(const SetStr &other) const
{
	SetStr interSet;

	for(int i=0; i<size(); i++){
		if(other.exists(list_.get(i))) interSet.insert(list_.get(i));
	}

	return interSet;
}

SetStr SetStr::operator|(const SetStr &other) const
{
	return setUnion(other);
}

SetStr SetStr::operator&(const SetStr &other) const
{
	return setIntersection(other);
}

SetStr::SetStr(const SetStr &other)
{
	list_ = other.list_;
  	nextLoc = 0;
}

SetStr& SetStr::operator=(const SetStr &other)
{
	list_ = other.list_;
  	nextLoc = 0;
	return *this;
}