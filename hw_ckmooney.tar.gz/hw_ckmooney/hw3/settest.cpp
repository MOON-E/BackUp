#include "setstr.h"
#include "gtest/gtest.h"

class StringSetTest : public testing::Test {
protected:
	
	StringSetTest() {
		
	}

	virtual ~StringSetTest() {
			
	}

	
	virtual void SetUp() {
		set.insert("do");
		set.insert("re");
		set.insert("mi");
	}

	virtual void TearDown() {
		
	}

	SetStr set, set1, set2, set3;
};

TEST_F(StringSetTest, Exists) {
	EXPECT_EQ(set.size(), 3);
	EXPECT_TRUE(set.exists("do"));
	EXPECT_TRUE(set.exists("re"));
	EXPECT_TRUE(set.exists("mi"));
	EXPECT_FALSE(set.exists("fa"));
}

TEST_F(StringSetTest, InsertNominal) {
	set.insert("fa");
	EXPECT_EQ(set.size(), 4);
	EXPECT_TRUE(set.exists("fa"));
}

TEST_F(StringSetTest, InsertRepeat) {
	set.insert("do");
	EXPECT_EQ(set.size(), 3);
}

TEST_F(StringSetTest, InsertMany) {
	set.insert("fa");
	set.insert("so");
	set.insert("so");
	set.insert("la");
	set.insert("ti");
	set.insert("do");
	EXPECT_EQ(set.size(), 7);
	EXPECT_TRUE(set.exists("fa"));
	EXPECT_TRUE(set.exists("so"));
	EXPECT_TRUE(set.exists("la"));
	EXPECT_TRUE(set.exists("ti"));
}

TEST_F(StringSetTest, RemoveNominal) {
	set.remove("re");
	EXPECT_EQ(set.size(), 2);
	EXPECT_FALSE(set.exists("re"));
}

TEST_F(StringSetTest, RemoveNon) {
	set.remove("fa");
	EXPECT_EQ(set.size(), 3);
}

TEST_F(StringSetTest, RemoveAll) {
	set.remove("do");
	set.remove("re");
	set.remove("mi");
	EXPECT_EQ(set.size(), 0);
	EXPECT_TRUE(set.empty());
}

TEST_F(StringSetTest, IntersectNominal) {
	set1.insert("do");
	set1.insert("re");
	set1.insert("mi");
	set1.insert("fa");
	
	set2.insert("so");
	set2.insert("la");
	set2.insert("ti");
	set2.insert("do");

	set3 = set1.setIntersection(set2);
	EXPECT_EQ(set3.size(), 1);
	EXPECT_TRUE(set3.exists("do"));

	set3 = set2 & set1;
	EXPECT_EQ(set3.size(), 1);
	EXPECT_TRUE(set3.exists("do"));
}

TEST_F(StringSetTest, IntersectEncompass) {
	set1.insert("do");
	set1.insert("re");
	set1.insert("mi");
	set1.insert("fa");

	set3 = set.setIntersection(set1);
	EXPECT_EQ(set3.size(), 3);
	EXPECT_TRUE(set3.exists("do"));
	EXPECT_TRUE(set3.exists("re"));
	EXPECT_TRUE(set3.exists("mi"));
	EXPECT_FALSE(set3.exists("fa"));

	set3 = set1 & set;
	EXPECT_EQ(set3.size(), 3);
	EXPECT_TRUE(set3.exists("do"));
	EXPECT_TRUE(set3.exists("re"));
	EXPECT_TRUE(set3.exists("mi"));
	EXPECT_FALSE(set3.exists("fa"));
}

TEST_F(StringSetTest, IntersectNone) {
	set1.insert("so");
	set1.insert("la");
	set1.insert("ti");

	set3 = set.setIntersection(set1);
	EXPECT_EQ(set3.size(), 0);
	EXPECT_TRUE(set3.empty());

	set3 = set1 & set;
	EXPECT_EQ(set3.size(), 0);
	EXPECT_TRUE(set3.empty());
}

TEST_F(StringSetTest, UnionNominal) {
	set2.insert("so");
	set2.insert("la");
	set2.insert("ti");
	set2.insert("do");

	set3 = set.setUnion(set2);
	EXPECT_EQ(set3.size(), 6);
	EXPECT_TRUE(set3.exists("so"));
	EXPECT_TRUE(set3.exists("la"));
	EXPECT_TRUE(set3.exists("ti"));

	set3 = set2 | set;
	EXPECT_EQ(set3.size(), 6);
	EXPECT_TRUE(set3.exists("so"));
	EXPECT_TRUE(set3.exists("la"));
	EXPECT_TRUE(set3.exists("ti"));
}

TEST_F(StringSetTest, UnionEncompass) {
	set1.insert("do");
	set1.insert("re");
	set1.insert("mi");
	set1.insert("fa");

	set3 = set.setUnion(set1);
	EXPECT_EQ(set3.size(), 4);
	EXPECT_TRUE(set3.exists("do"));
	EXPECT_TRUE(set3.exists("re"));
	EXPECT_TRUE(set3.exists("mi"));
	EXPECT_TRUE(set3.exists("fa"));

	set3 = set1 | set;
	EXPECT_EQ(set3.size(), 4);
	EXPECT_TRUE(set3.exists("do"));
	EXPECT_TRUE(set3.exists("re"));
	EXPECT_TRUE(set3.exists("mi"));
	EXPECT_TRUE(set3.exists("fa"));
}