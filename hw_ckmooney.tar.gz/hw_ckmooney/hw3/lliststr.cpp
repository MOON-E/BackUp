#include "lliststr.h"
#include <cstdlib>
#include <stdexcept>
#include <string>

using namespace std;

LListStr::LListStr()
{
  head_ = NULL;
  tail_ = NULL;
  size_ = 0;
}

LListStr::~LListStr()
{
  clear();
}

bool LListStr::empty() const
{
  return size_ == 0;
}

int LListStr::size() const
{
  return size_;
}

/**
 * Complete the following function
 */
void LListStr::insert(int loc, const string& val)
{
	Item *newItem = new Item;
	newItem->val = val;

	if (loc==0) {
		if (empty()) {
			head_ = newItem;
			tail_ = newItem;
			newItem->next = NULL;
			newItem->prev = NULL;
		}
		else {
			newItem->prev = NULL;
			newItem->next = head_;
			head_->prev = newItem;
			head_ = newItem;
		}
	}

	else if (loc==size_){
		newItem->prev = tail_;
		newItem->next = NULL;
		tail_->next = newItem;
		tail_ = newItem;
	}

	else if (loc<0 || loc>size_){	
		//nothing
	}

	else {
		Item *prevItem = getNodeAt(loc-1);
		Item *nextItem = getNodeAt(loc);

		newItem->next = nextItem;
		newItem->prev = prevItem;

		prevItem->next = newItem;
		nextItem->prev = newItem;
	}

	size_++;
}

/**
 * Complete the following function
 */
void LListStr::remove(int loc)
{
	
	if (loc==0) {
		if(size_==1){
			delete head_;
			head_ = NULL;
			tail_ = NULL;
		}
		else {
			Item *newHead = head_->next;

			newHead->prev = NULL;
			delete head_;
			head_ = newHead;
		}
	}

	else if (loc==(size_-1)){
		Item *newTail = tail_->prev;

		newTail->next = NULL;
		delete tail_;
		tail_ = newTail;
	}

	else if (loc<0 || loc>(size_-1)){	
		//nothing
	}

	else {
		Item *removedItem = getNodeAt(loc);
		Item *prevItem = removedItem->prev;
		Item *nextItem = removedItem->next;

		delete removedItem;
		prevItem->next = nextItem;
		nextItem->prev = prevItem;

	}

	size_--;
}

void LListStr::set(int loc, const string& val)
{
  Item *temp = getNodeAt(loc);
  temp->val = val;
}

string& LListStr::get(int loc)
{
  if(loc < 0 || loc >= size_){
    throw std::invalid_argument("bad location");
  }
  Item *temp = getNodeAt(loc);
  return temp->val;
}

string const & LListStr::get(int loc) const
{
  if(loc < 0 || loc >= size_){
    throw std::invalid_argument("bad location");
  }
  Item *temp = getNodeAt(loc);
  return temp->val;
}

void LListStr::clear()
{
  while(head_ != NULL){
    Item *temp = head_->next;
    delete head_;
    head_ = temp;
  }
  tail_ = NULL;
  size_ = 0;
}

void LListStr::push_back(const string& val)
{
	insert(size_, val);
}

LListStr::LListStr(const LListStr &other)
{
	size_ = other.size_;
	head_ = NULL;
	tail_ = NULL;

	for(int i=0; i<size_; i++){
		insert(i, other.get(i));
	}
}

LListStr& LListStr::operator=(const LListStr &other)
{
	if(this==&other) return *this;
	clear();

	for(int i=0; i<other.size_; i++){
		insert(i, other.get(i));
	}
	return *this;
}

LListStr::Item* LListStr::getNodeAt(int loc) const
{
  Item *temp = head_;
  if(loc >= 0 && loc < size_){
    while(temp != NULL && loc > 0){
      temp = temp->next;
      loc--;
    }
    return temp;
  }
  else {
    //throw std::invalid_argument("bad location");
    return NULL;
  }
}