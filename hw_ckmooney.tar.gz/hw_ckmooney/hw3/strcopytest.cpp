#include "lliststr.h"
#include <string>
#include <iostream>

using namespace std;

int main() {
  LListStr * list = new LListStr();

  // Check if the list is initially empty.
  if (list->empty()) {
    cout << "SUCCESS: List is empty initially." << endl;
  } else {
    cout << "FAIL: List is not empty initially when it should be." << endl;
  }

  // Push back on empty
  list->push_back("test");

  // Check size
  if (list->size()==1) {
    cout << "SUCCESS: List is correct size after push back." << endl;
  } else {
    cout << "FAIL: List is not correct size after push back." << endl;
  }

  // Check value
  if (list->get(0)=="test") {
    cout << "SUCCESS: String is correct." << endl;
  } else {
    cout << "FAIL: String is incorrect." << endl;
  }

  // Push back more
  list->push_back("a");
  list->push_back("b");
  list->push_back("c");

  // Check size
  if (list->size()==4) {
    cout << "SUCCESS: List is correct size after push back." << endl;
  } else {
    cout << "FAIL: List is not correct size after push back." << endl;
  }

  // Construct Copy
  LListStr* copyList(list);

  // Check size
  if (copyList->size()==4) {
    cout << "SUCCESS: List copy is correct size after copy." << endl;
  } else {
    cout << "FAIL: List copy is not correct size after copy." << endl;
  }

  // Check members
  for (int i=0; i<4; i++){
    if (list->get(i)==copyList->get(i)) {
      cout << "SUCCESS: Element " << i << " matches." << endl;
    } else {
      cout << "FAIL: Element " << i << " does not match." << endl;
    }
  }

  // Create third list
  LListStr * listThree = new LListStr();
  listThree->push_back("do");
  listThree->push_back("re");
  listThree->push_back("mi");

  // Check size
  if (listThree->size()==3) {
    cout << "SUCCESS: List is correct size." << endl;
  } else {
    cout << "FAIL: List is not correct size." << endl;
  }

  // Assign
  copyList = listThree;

  // Check size
  if (copyList->size()==3) {
    cout << "SUCCESS: List copy is correct size after copy." << endl;
  } else {
    cout << "FAIL: List copy is not correct size after copy." << endl;
  }

  // Check members
  for (int i=0; i<3; i++){
    if (listThree->get(i)==copyList->get(i)) {
      cout << "SUCCESS: Element " << i << " matches." << endl;
    } else {
      cout << "FAIL: Element " << i << " does not match." << endl;
    }
  }

  // Clean up memory.
  delete list;
  delete listThree;
}
