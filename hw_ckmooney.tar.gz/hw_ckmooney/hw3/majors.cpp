#include <cctype>
#include <map>
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>

#include "setstr.h"

using namespace std;

void capitalize(string &str)						//Capitalization function
{
	for(unsigned int i=0; i<str.size(); i++){
		str[i] = toupper(str[i]);
	}
}

void cleanUp(string &str)							//Removes spaces at end of names
{
	if(isspace(str[str.size()-1])){
		str.erase(str.size()-1);
		cleanUp(str);
	}
}

int main(int argc, char* argv[])
{
	map<string, SetStr> stumap;

	//Initialization
	ifstream infile(argv[1]);
	ifstream cmdfile(argv[2]);
	ofstream outfile(argv[3]);

	string holdString;
	int commaLoc;
	string name;
	string major;

	//Input
	while(getline(infile, holdString)){
		commaLoc = holdString.find(',');			//Find where the comma is

		name = holdString.substr(0, commaLoc);		//Stuff before comma = name
		holdString.erase(0, commaLoc+1);			//Erase name
		stringstream ss(holdString);				//Setup stringstream

		cleanUp(name);

		if(stumap.find(name) == stumap.end()) {		//Add student if not present
			SetStr newmajors;
			stumap[name] = newmajors;
		}
		while(ss >> major) {						//Add majors to SetStr
			capitalize(major);
			stumap[name].insert(major);
		}
	}

	//Command & Output
	while(getline(cmdfile, holdString)){
		capitalize(holdString);						//Capitalize cmd line

		stringstream ss(holdString);				//Setup stringstream
		outfile << holdString << endl;				//Print it

		vector<SetStr> setHold;						//Setup set vector

		while(ss >> major) {						//Fill sets with matching students
			SetStr stuHold;

			for(map<string, SetStr>::iterator it=stumap.begin(); it!=stumap.end(); ++it) {
				if(it->second.exists(major)){
					stuHold.insert(it->first);
				}
			}

			setHold.push_back(stuHold);
		}

		while(setHold.size()>1){					//Combine all sets into one
			setHold[0] = setHold[0] & setHold.back();
			setHold.pop_back();
		}

		for(map<string, SetStr>::iterator it=stumap.begin(); it!=stumap.end(); ++it) {
			if(setHold[0].exists(it->first)){
				outfile << it->first << endl;
			}
		}

		outfile << endl;
	}
}